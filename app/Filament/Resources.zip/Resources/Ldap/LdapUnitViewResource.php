<?php

namespace App\Filament\Resources\Ldap;

use App\Filament\Resources\Ldap\LdapUnitViewResource\Pages;
use App\Models\LdapUnitView;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class LdapUnitViewResource extends Resource
{
    protected static ?string $model = LdapUnitView::class;

    protected static string | \UnitEnum | null $navigationGroup = 'LDAP Management';
    protected static string | \BackedEnum | null $navigationIcon = 'heroicon-o-building-office-2';
    protected static ?string $navigationLabel = 'Units Roles';
    protected static ?string $modelLabel = 'Unit';
    protected static ?string $pluralModelLabel = 'Units';
    protected static ?int $navigationSort = 22;

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            TextInput::make('cn')
                ->label('Unit CN')
                ->required(),

            Textarea::make('description')
                ->label('Description')
                ->rows(3),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->striped()
            ->emptyStateHeading('No units found')
            ->emptyStateDescription('OU units memang boleh kosong, tetapi fitur create/edit/delete tetap tersedia.')
            ->columns([
                TextColumn::make('cn')
                    ->label('Unit')
                    ->searchable()
                    ->sortable()
                    ->weight('600'),

                TextColumn::make('description')
                    ->label('Description')
                    ->default('-')
                    ->wrap(),

                TextColumn::make('synced_at')
                    ->label('Synced')
                    ->dateTime('Y-m-d H:i:s')
                    ->sortable(),
            ])
            ->defaultSort('cn');
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListLdapUnitViews::route('/'),
        ];
    }
}
