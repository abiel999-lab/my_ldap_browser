<?php

namespace App\Filament\Resources\Ldap\LdapAppRoleMemberViewResource\Pages;

use App\Filament\Resources\Ldap\LdapAppRoleMemberViewResource;
use App\Models\LdapAppRoleView;
use App\Models\LdapUserView;
use App\Services\Ldap\LdapAppRoleMemberService;
use App\Services\Ldap\LdapAppSyncService;
use Filament\Actions;
use Filament\Forms\Components\Select;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\ListRecords;
use Illuminate\Database\Eloquent\Builder;

class ListLdapAppRoleMemberViews extends ListRecords
{
    protected static string $resource = LdapAppRoleMemberViewResource::class;

    public ?string $app = null;
    public ?string $role = null;

    public function mount(): void
    {
        $this->app = request()->query('app');
        $this->role = request()->query('role');
    }

    public function getTitle(): string
    {
        return 'App Role Members - ' . ($this->app ?: '-') . ' - ' . ($this->role ?: '-');
    }

    protected function getHeaderActions(): array
    {
        return [
            Actions\Action::make('backToAppRoles')
                ->label('Back')
                ->icon('heroicon-o-arrow-left')
                ->color('gray')
                ->url(\App\Filament\Resources\Ldap\LdapAppViewResource::getUrl('index', [
                    'app' => $this->app,
                ])),

            Actions\Action::make('addUserToRole')
                ->label('Add User to Role')
                ->icon('heroicon-o-plus')
                ->color('primary')
                ->form([
                    Select::make('uid')
                        ->label('User')
                        ->options(fn () => LdapUserView::query()
                            ->orderBy('uid')
                            ->get()
                            ->mapWithKeys(fn ($user) => [
                                $user->uid => "{$user->uid} - {$user->cn}"
                            ])
                            ->toArray()
                        )
                        ->searchable()
                        ->required(),
                ])
                ->action(function (array $data) {
                    try {
                        app(LdapAppRoleMemberService::class)->assignUserToAppRole(
                            (string) $this->app,
                            (string) $this->role,
                            (string) $data['uid']
                        );

                        Notification::make()
                            ->title('User added to app role successfully')
                            ->success()
                            ->send();

                        $this->redirect(request()->fullUrl());
                    } catch (\Throwable $e) {
                        Notification::make()
                            ->title('Failed to add user to app role')
                            ->body($e->getMessage())
                            ->danger()
                            ->send();
                    }
                }),

            Actions\Action::make('removeUserFromRole')
                ->label('Remove User from Role')
                ->icon('heroicon-o-trash')
                ->color('danger')
                ->requiresConfirmation()
                ->form([
                    Select::make('uid')
                        ->label('User')
                        ->options(function () {
                            $roleView = LdapAppRoleView::query()
                                ->where('app_cn', $this->app)
                                ->where('role_cn', $this->role)
                                ->first();

                            if (! $roleView) {
                                return [];
                            }

                            $memberDns = collect($roleView->members ?? []);

                            $uids = $memberDns
                                ->map(function ($dn) {
                                    if (preg_match('/uid=([^,]+)/i', (string) $dn, $matches)) {
                                        return $matches[1];
                                    }

                                    return null;
                                })
                                ->filter()
                                ->reject(fn ($uid) => strtolower((string) $uid) === 'dummy')
                                ->values();

                            return LdapUserView::query()
                                ->whereIn('uid', $uids)
                                ->orderBy('uid')
                                ->get()
                                ->mapWithKeys(fn ($user) => [
                                    $user->uid => "{$user->uid} - {$user->cn}"
                                ])
                                ->toArray();
                        })
                        ->searchable()
                        ->required(),
                ])
                ->action(function (array $data) {
                    try {
                        app(LdapAppRoleMemberService::class)->removeUserFromAppRole(
                            (string) $this->app,
                            (string) $this->role,
                            (string) $data['uid']
                        );

                        Notification::make()
                            ->title('User removed from app role successfully')
                            ->success()
                            ->send();

                        $this->redirect(request()->fullUrl());
                    } catch (\Throwable $e) {
                        Notification::make()
                            ->title('Failed to remove user from app role')
                            ->body($e->getMessage())
                            ->danger()
                            ->send();
                    }
                }),

            Actions\Action::make('syncRoleMembers')
                ->label('Sync Role Members')
                ->icon('heroicon-o-arrow-path')
                ->color('gray')
                ->action(function () {
                    app(LdapAppSyncService::class)->sync();

                    Notification::make()
                        ->title('App role members synced successfully')
                        ->success()
                        ->send();

                    $this->redirect(request()->fullUrl());
                }),
        ];
    }

    protected function getTableQuery(): Builder
    {
        $roleView = LdapAppRoleView::query()
            ->where('app_cn', $this->app)
            ->where('role_cn', $this->role)
            ->first();

        if (! $roleView) {
            return LdapUserView::query()->whereRaw('1 = 0');
        }

        $memberDns = collect($roleView->members ?? []);

        $uids = $memberDns
            ->map(function ($dn) {
                if (preg_match('/uid=([^,]+)/i', (string) $dn, $matches)) {
                    return $matches[1];
                }

                return null;
            })
            ->filter()
            ->reject(fn ($uid) => strtolower((string) $uid) === 'dummy')
            ->values()
            ->all();

        if (empty($uids)) {
            return LdapUserView::query()->whereRaw('1 = 0');
        }

        return LdapUserView::query()->whereIn('uid', $uids);
    }
}
