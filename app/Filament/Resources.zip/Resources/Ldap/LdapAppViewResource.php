<?php

namespace App\Filament\Resources\Ldap;

use App\Filament\Resources\Ldap\LdapAppViewResource\Pages;
use App\Models\LdapAppView;
use Filament\Forms\Components\TextInput;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class LdapAppViewResource extends Resource
{
    protected static ?string $model = LdapAppView::class;

    protected static string | \UnitEnum | null $navigationGroup = 'LDAP Management';
    protected static string | \BackedEnum | null $navigationIcon = 'heroicon-o-window';
    protected static ?string $navigationLabel = 'App Roles';
    protected static ?string $modelLabel = 'App';
    protected static ?string $pluralModelLabel = 'App Roles';
    protected static ?int $navigationSort = 21;

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            TextInput::make('cn')->disabled(),
            TextInput::make('description')->disabled(),
            TextInput::make('role_count')->disabled(),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->striped()
            ->columns([
                TextColumn::make('cn')
                    ->label('App')
                    ->searchable()
                    ->sortable()
                    ->weight('600'),

                TextColumn::make('description')
                    ->label('Description')
                    ->default('-')
                    ->wrap(),

                TextColumn::make('role_count')
                    ->label('Roles')
                    ->sortable(),

                TextColumn::make('synced_at')
                    ->label('Synced')
                    ->dateTime('Y-m-d H:i:s')
                    ->sortable(),
            ])
            ->defaultSort('cn')
            ->recordUrl(fn ($record) => Pages\ListLdapAppViews::getUrl([
                'app' => $record->cn,
            ]));
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListLdapAppViews::route('/'),
        ];
    }
}
