<?php

namespace App\Filament\Resources\Ldap\LdapUserViewResource\Pages;

use App\Filament\Resources\Ldap\LdapUserViewResource;
use App\Models\LdapUserView;
use App\Services\Ldap\LdapAuditTrailService;
use App\Services\Ldap\LdapRoleSyncService;
use App\Services\Ldap\LdapUserCrudService;
use App\Services\Ldap\LdapUserSyncService;
use Filament\Actions;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\ListRecords;
use Illuminate\Database\Eloquent\Collection;

class ListLdapUserViews extends ListRecords
{
    protected static string $resource = LdapUserViewResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\Action::make('createLdapUser')
                ->label('Create User')
                ->icon('heroicon-o-plus')
                ->color('primary')
                ->url(LdapUserViewResource::getUrl('create')),

            Actions\Action::make('syncLdap')
                ->label('Sync LDAP')
                ->icon('heroicon-o-arrow-path')
                ->color('gray')
                ->action(function () {
                    app(LdapRoleSyncService::class)->sync();
                    app(LdapUserSyncService::class)->sync();

                    Notification::make()
                        ->title('Users and roles synced successfully')
                        ->success()
                        ->send();

                    $this->redirect(static::getResource()::getUrl('index'));
                }),
        ];
    }

    protected function getTableBulkActions(): array
    {
        return [
            Actions\BulkAction::make('deleteSelectedUsers')
                ->label('Delete Selected Users')
                ->icon('heroicon-o-trash')
                ->color('danger')
                ->requiresConfirmation()
                ->modalHeading('Delete selected users')
                ->modalDescription('User yang dipilih akan dihapus dari LDAP. Proses ini tidak bisa dibatalkan.')
                ->modalSubmitActionLabel('Yes, delete selected users')
                ->deselectRecordsAfterCompletion()
                ->action(function (Collection $records) {
                    $successCount = 0;
                    $failedCount = 0;
                    $failedUsers = [];

                    /** @var LdapUserCrudService $userCrud */
                    $userCrud = app(LdapUserCrudService::class);

                    /** @var LdapAuditTrailService $auditTrail */
                    $auditTrail = app(LdapAuditTrailService::class);

                    foreach ($records as $record) {
                        $uid = (string) $record->uid;
                        $dn = (string) $record->dn;
                        $before = $record->toArray();

                        $ldapStatus = 'failed';
                        $syncStatus = 'not_run';

                        try {
                            $deleteResult = $userCrud->deleteByDn($dn);
                            $ldapStatus = 'success';
                            $successCount++;

                            $auditTrail->log(
                                action: 'delete_user_batch',
                                targetUid: $uid,
                                targetDn: $deleteResult['dn'],
                                beforeData: $before,
                                afterData: null,
                                status: 'success',
                                ldapStatus: $ldapStatus,
                                syncStatus: $syncStatus,
                                message: 'LDAP user deleted successfully via batch delete.',
                                errorMessage: null
                            );
                        } catch (\Throwable $e) {
                            $failedCount++;
                            $failedUsers[] = $uid !== '' ? $uid : $dn;

                            $auditTrail->log(
                                action: 'delete_user_batch',
                                targetUid: $uid,
                                targetDn: $dn,
                                beforeData: $before,
                                afterData: null,
                                status: 'failed',
                                ldapStatus: $ldapStatus,
                                syncStatus: $syncStatus,
                                message: 'Batch delete user failed.',
                                errorMessage: $e->getMessage()
                            );
                        }
                    }

                    $finalSyncStatus = 'not_run';

                    try {
                        app(LdapRoleSyncService::class)->sync();
                        app(LdapUserSyncService::class)->sync();
                        $finalSyncStatus = 'success';
                    } catch (\Throwable $syncException) {
                        $finalSyncStatus = 'failed';
                    }

                    if ($successCount > 0 && $finalSyncStatus === 'failed') {
                        Notification::make()
                            ->title("Batch delete selesai: {$successCount} sukses, {$failedCount} gagal")
                            ->body('Delete LDAP berhasil, tetapi sync local view gagal. Jalankan Sync LDAP.')
                            ->warning()
                            ->send();

                        return;
                    }

                    if ($failedCount > 0) {
                        $body = 'Success: ' . $successCount . ', Failed: ' . $failedCount;

                        if (! empty($failedUsers)) {
                            $body .= '. Failed users: ' . implode(', ', array_slice($failedUsers, 0, 10));
                        }

                        Notification::make()
                            ->title('Batch delete completed with some failures')
                            ->body($body)
                            ->warning()
                            ->send();

                        return;
                    }

                    Notification::make()
                        ->title("Batch delete successful: {$successCount} users deleted")
                        ->success()
                        ->send();

                    $this->redirect(static::getResource()::getUrl('index'));
                }),
        ];
    }
}
