<?php

namespace App\Filament\Resources\Ldap\LdapEditableObjectClassResource\Pages;

use App\Filament\Resources\Ldap\LdapEditableObjectClassResource;
use App\Services\Ldap\LdapSchemaEditorService;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\CreateRecord;

class CreateLdapEditableObjectClass extends CreateRecord
{
    protected static string $resource = LdapEditableObjectClassResource::class;

    protected function handleRecordCreation(array $data): \Illuminate\Database\Eloquent\Model
    {
        app(LdapSchemaEditorService::class)->addObjectClass($data);

        Notification::make()
            ->title('ObjectClass created successfully')
            ->success()
            ->send();

        return \App\Models\LdapEditableObjectClass::query()->latest('id')->firstOrFail();
    }
}
