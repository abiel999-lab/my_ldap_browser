<?php

namespace App\Filament\Resources\Ldap\LdapEditableObjectClassResource\Pages;

use App\Filament\Resources\Ldap\LdapEditableObjectClassResource;
use App\Services\Ldap\LdapSchemaEditorService;
use Filament\Actions;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\ListRecords;

class ListLdapEditableObjectClasses extends ListRecords
{
    protected static string $resource = LdapEditableObjectClassResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),

            Actions\Action::make('sync')
                ->label('Sync From LDAP')
                ->icon('heroicon-o-arrow-path')
                ->color('gray')
                ->action(function () {
                    app(LdapSchemaEditorService::class)->syncSnapshots();

                    Notification::make()
                        ->title('Schema ObjectClasses synced successfully')
                        ->success()
                        ->send();
                }),
        ];
    }
}
