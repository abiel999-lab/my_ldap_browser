<?php

namespace App\Filament\Resources\Ldap\LdapEditableObjectClassResource\Pages;

use App\Filament\Resources\Ldap\LdapEditableObjectClassResource;
use App\Services\Ldap\LdapSchemaEditorService;
use Filament\Actions;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\EditRecord;

class EditLdapEditableObjectClass extends EditRecord
{
    protected static string $resource = LdapEditableObjectClassResource::class;

    protected function handleRecordUpdate(\Illuminate\Database\Eloquent\Model $record, array $data): \Illuminate\Database\Eloquent\Model
    {
        app(LdapSchemaEditorService::class)->updateObjectClass($record, $data);

        Notification::make()
            ->title('ObjectClass updated successfully')
            ->success()
            ->send();

        return $record->refresh();
    }

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make()
                ->action(function () {
                    app(LdapSchemaEditorService::class)->deleteObjectClass($this->record);

                    Notification::make()
                        ->title('ObjectClass deleted successfully')
                        ->success()
                        ->send();

                    $this->redirect(LdapEditableObjectClassResource::getUrl('index'));
                }),
        ];
    }
}
