<?php

namespace App\Filament\Resources\Ldap;

use App\Filament\Resources\Ldap\LdapEditableObjectClassResource\Pages;
use App\Models\LdapEditableObjectClass;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Tables\Actions\DeleteAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class LdapEditableObjectClassResource extends Resource
{
    protected static ?string $model = LdapEditableObjectClass::class;

    protected static string | \UnitEnum | null $navigationGroup = 'LDAP Management';
    protected static string | \BackedEnum | null $navigationIcon = 'heroicon-o-squares-2x2';
    protected static ?string $navigationLabel = 'Schema ObjectClasses';
    protected static ?string $modelLabel = 'ObjectClass';
    protected static ?string $pluralModelLabel = 'Schema ObjectClasses';
    protected static ?int $navigationSort = 72;

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            TextInput::make('oid')
                ->label('OID')
                ->required(),

            TextInput::make('aliases_text')
                ->label('Aliases')
                ->required()
                ->helperText('Pisahkan dengan koma.'),

            Textarea::make('description')
                ->label('Description')
                ->rows(3),

            TextInput::make('sup_text')
                ->label('Superior Classes')
                ->helperText('Pisahkan dengan koma.'),

            Select::make('class_type')
                ->label('Class Type')
                ->options([
                    'ABSTRACT' => 'ABSTRACT',
                    'STRUCTURAL' => 'STRUCTURAL',
                    'AUXILIARY' => 'AUXILIARY',
                ])
                ->required()
                ->default('STRUCTURAL'),

            Toggle::make('obsolete')
                ->label('Obsolete'),

            TextInput::make('must_text')
                ->label('MUST Attributes')
                ->helperText('Pisahkan dengan koma.'),

            TextInput::make('may_text')
                ->label('MAY Attributes')
                ->helperText('Pisahkan dengan koma.'),

            Textarea::make('raw_definition')
                ->label('Raw Definition')
                ->disabled()
                ->rows(8),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->striped()
            ->columns([
                TextColumn::make('primary_name')
                    ->label('Name')
                    ->searchable()
                    ->sortable()
                    ->weight('600'),

                TextColumn::make('oid')
                    ->label('OID')
                    ->searchable()
                    ->sortable(),

                TextColumn::make('description')
                    ->label('Description')
                    ->wrap()
                    ->default('-'),

                TextColumn::make('class_type')
                    ->label('Type')
                    ->sortable(),

                TextColumn::make('sup_text')
                    ->label('SUP')
                    ->default('-')
                    ->wrap(),
            ])
            ->defaultSort('primary_name');
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListLdapEditableObjectClasses::route('/'),
            'create' => Pages\CreateLdapEditableObjectClass::route('/create'),
            'edit' => Pages\EditLdapEditableObjectClass::route('/{record}/edit'),
        ];
    }
}
