<?php

namespace App\Filament\Resources\Ldap\LdapEditableAttributeTypeResource\Pages;

use App\Filament\Resources\Ldap\LdapEditableAttributeTypeResource;
use App\Services\Ldap\LdapSchemaEditorService;
use Filament\Actions;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\EditRecord;

class EditLdapEditableAttributeType extends EditRecord
{
    protected static string $resource = LdapEditableAttributeTypeResource::class;

    protected function handleRecordUpdate(\Illuminate\Database\Eloquent\Model $record, array $data): \Illuminate\Database\Eloquent\Model
    {
        app(LdapSchemaEditorService::class)->updateAttributeType($record, $data);

        Notification::make()
            ->title('AttributeType updated successfully')
            ->success()
            ->send();

        return $record->refresh();
    }

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make()
                ->action(function () {
                    app(LdapSchemaEditorService::class)->deleteAttributeType($this->record);

                    Notification::make()
                        ->title('AttributeType deleted successfully')
                        ->success()
                        ->send();

                    $this->redirect(LdapEditableAttributeTypeResource::getUrl('index'));
                }),
        ];
    }
}
