<?php

namespace App\Filament\Resources\Ldap\LdapEditableAttributeTypeResource\Pages;

use App\Filament\Resources\Ldap\LdapEditableAttributeTypeResource;
use App\Services\Ldap\LdapSchemaEditorService;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\CreateRecord;

class CreateLdapEditableAttributeType extends CreateRecord
{
    protected static string $resource = LdapEditableAttributeTypeResource::class;

    protected function handleRecordCreation(array $data): \Illuminate\Database\Eloquent\Model
    {
        app(LdapSchemaEditorService::class)->addAttributeType($data);

        Notification::make()
            ->title('AttributeType created successfully')
            ->success()
            ->send();

        return \App\Models\LdapEditableAttributeType::query()->latest('id')->firstOrFail();
    }
}
