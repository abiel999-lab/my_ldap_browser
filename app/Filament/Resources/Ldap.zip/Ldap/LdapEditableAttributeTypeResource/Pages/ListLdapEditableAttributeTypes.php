<?php

namespace App\Filament\Resources\Ldap\LdapEditableAttributeTypeResource\Pages;

use App\Filament\Resources\Ldap\LdapEditableAttributeTypeResource;
use App\Services\Ldap\LdapSchemaEditorService;
use Filament\Actions;
use Filament\Notifications\Notification;
use Filament\Resources\Pages\ListRecords;

class ListLdapEditableAttributeTypes extends ListRecords
{
    protected static string $resource = LdapEditableAttributeTypeResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),

            Actions\Action::make('sync')
                ->label('Sync From LDAP')
                ->icon('heroicon-o-arrow-path')
                ->color('gray')
                ->action(function () {
                    app(LdapSchemaEditorService::class)->syncSnapshots();

                    Notification::make()
                        ->title('Schema AttributeTypes synced successfully')
                        ->success()
                        ->send();
                }),
        ];
    }
}
