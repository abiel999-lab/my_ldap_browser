<?php

namespace App\Filament\Resources\Ldap;

use App\Filament\Resources\Ldap\LdapEditableAttributeTypeResource\Pages;
use App\Models\LdapEditableAttributeType;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class LdapEditableAttributeTypeResource extends Resource
{
    protected static ?string $model = LdapEditableAttributeType::class;

    protected static string | \UnitEnum | null $navigationGroup = 'LDAP Management';
    protected static string | \BackedEnum | null $navigationIcon = 'heroicon-o-bars-3-bottom-left';
    protected static ?string $navigationLabel = 'Schema AttributeTypes';
    protected static ?string $modelLabel = 'AttributeType';
    protected static ?string $pluralModelLabel = 'Schema AttributeTypes';
    protected static ?int $navigationSort = 73;

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            TextInput::make('oid')
                ->label('OID')
                ->required(),

            TextInput::make('aliases_text')
                ->label('Aliases')
                ->required()
                ->helperText('Pisahkan dengan koma.'),

            Textarea::make('description')
                ->label('Description')
                ->rows(3),

            TextInput::make('sup')
                ->label('Superior Type'),

            TextInput::make('equality')
                ->label('Equality'),

            TextInput::make('ordering')
                ->label('Ordering'),

            TextInput::make('substr')
                ->label('Substring'),

            TextInput::make('syntax')
                ->label('Syntax OID'),

            TextInput::make('usage')
                ->label('Usage'),

            Toggle::make('single_value')
                ->label('Single Value'),

            Toggle::make('no_user_modification')
                ->label('No User Modification'),

            Toggle::make('obsolete')
                ->label('Obsolete'),

            Textarea::make('raw_definition')
                ->label('Raw Definition')
                ->disabled()
                ->rows(8),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->striped()
            ->columns([
                TextColumn::make('primary_name')
                    ->label('Name')
                    ->searchable()
                    ->sortable()
                    ->weight('600'),

                TextColumn::make('oid')
                    ->label('OID')
                    ->searchable()
                    ->sortable(),

                TextColumn::make('description')
                    ->label('Description')
                    ->wrap()
                    ->default('-'),

                TextColumn::make('syntax')
                    ->label('Syntax')
                    ->default('-')
                    ->wrap(),

                TextColumn::make('usage')
                    ->label('Usage')
                    ->default('-')
                    ->sortable(),
            ])
            ->defaultSort('primary_name');
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListLdapEditableAttributeTypes::route('/'),
            'create' => Pages\CreateLdapEditableAttributeType::route('/create'),
            'edit' => Pages\EditLdapEditableAttributeType::route('/{record}/edit'),
        ];
    }
}
